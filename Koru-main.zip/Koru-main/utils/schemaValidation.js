const zod = require("zod");

const listingSchema = zod.object({
    title: zod.string().min(2,"Title must be at least 2 characters long"),
    price: zod.coerce.number().min(0,"Price cannot be negative"),
    description: zod.string().min(10,"Description must be at least 10 characters long"),
    image:zod.string()
    .url("Invalid URL")
    .optional()
    .or(zod.literal("")),
    location: zod.string().min(2,"Location must be at least 2 characters long"),
    country: zod.string().min(2,"Country must be at least 2 characters long")
});

const reviewSchema = zod.object({
    rating : zod.coerce.number().min(1,"Rating must be at least 1").max(5,"Rating cannot be more than 5"),
    comment : zod.string().min(5,"Comment must be at least 5 characters long")
});

const userSchema = zod.object({
    email: zod.email(),
    name : zod.string().min(2,"Name must have atleast 2 characters !"),
    age : zod.coerce.number().min(12,"Age cannot be less than 12"),
    username : zod.string().nonempty("Username cannot be empty !"),
    password : zod.string()
})
module.exports = {listingSchema , reviewSchema , userSchema};

    
