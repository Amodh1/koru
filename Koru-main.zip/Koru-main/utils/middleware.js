const customError = require("./customError");
const Listing = require("../models/listing");
const Review = require("../models/review");
const { listingSchema , userSchema , reviewSchema } = require("./schemaValidation");
const isLoggedIn = (req, res, next) => {
  if (!req.isAuthenticated()) {
    req.session.redirectURL = req.originalUrl ;
    req.flash("error", "You need to login first !");
    res.redirect("/users/login");
  } else {
    next();
  }
};
const isOwner = async(req,res,next)=>{
  const listing = await Listing.findById(req.params.id).populate("owner");
  if(req.user.username === listing.owner.username)
    next();
  else{
    req.flash("error","You are not the owner of this listing!");
    res.redirect(`/listings/${req.params.id}`);
  }
}
const isAuthor = async(req,res,next)=>{
  // const listing = await Listing.findById(req.params.id).populate("reviews")
  const rev = await Review.findById(req.params.reviewId).populate("author")
  if(rev.author.username === req.user.username) 
  next();
  else{
    req.flash("error", "Your are not the Author of this review!");
    res.redirect(`/listings/${req.params.id}`);
  }
}
const saveRedirectPath = (req, res, next) => {
  if (req.session.redirectURL) {
    res.locals.redirectURL = req.session.redirectURL ; 
  }
  next();
};
const validateListing = (req, res, next) => {
  const result = listingSchema.safeParse(req.body);
  if (!result.success) {
    const issues = result.error.issues; //issues is an array of error objects.each issue contains error message
    const errorMessages = issues.map((issue) => issue.message).join(", ");
    throw new customError(400, errorMessages);
  } else {
    next();
  }
};
const validateUser = (req,res,next)=>{
    const result = userSchema.safeParse(req.body.user);
    if(!result.success){
        const issues = result.error.issues;
        const errorMessages = issues.map(issue => issue.message).join(", ");
        throw new customError(400,errorMessages);
    }
    else{
        next();
    }
}
const validateReview = (req,res,next)=>{
    const result = reviewSchema.safeParse(req.body.review);   
    if(!result.success){
        const issues = result.error.issues;
        const errorMessages = issues.map(issue => issue.message).join(", ");
        throw new customError(400,errorMessages);
    }
    else{
        next();
    }   
}
module.exports = {isLoggedIn,isOwner,isAuthor,saveRedirectPath,validateListing,validateUser,validateReview};
