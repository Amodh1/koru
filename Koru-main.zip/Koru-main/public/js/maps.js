const map = new maptilersdk.Map({
  container: 'map', // container's id or the HTML element to render the map
  style: maptilersdk.MapStyle.STREETS,
  center: centerVal,
  zoom: 13,
  apiKey : "zgvwmj5vTPudggwSmWOV",
});
const marker = new maptilersdk.Marker()
  .setLngLat(centerVal)
  .addTo(map);