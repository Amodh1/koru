const Listing = require("../models/listing");
const Review = require("../models/review");
const User = require("../models/user")
module.exports.show = async (req, res, next) => {
      let { id } = req.params;
      const findListing = await Listing.findById(id).populate("reviews");
      res.render("listings/show.ejs", { findListing });
    }
module.exports.createReview = async (req, res) => {
      let { id } = req.params;
      let listing = await Listing.findById(id);
      let newReview = new Review(req.body.review);
      let authorr = await User.findById(req.user.id);
      newReview.author=authorr;
      listing.reviews.push(newReview);
      await newReview.save();
      await listing.save();
      res.redirect(`/listings/${id}`);
    }
module.exports.destroyReview = async (req, res) => {
    const { id, reviewId } = req.params;
    await Listing.findByIdAndUpdate(id, { $pull: { reviews: reviewId } });
    await Review.findByIdAndDelete(reviewId);
    res.redirect(`/listings/${id}`);
  }