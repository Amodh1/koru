const Listing = require("../models/listing");
const Review = require("../models/review");
module.exports.index = async(req,res)=>{
    const allListing =await Listing.find();
    res.render("listings/listing.ejs",{allListing});
    console.log("Rendered all the listings");
}
module.exports.new = (req,res)=>{
    res.render("listings/new.ejs");
}
module.exports.show = async(req,res)=>{
    let {id} = req.params;
    const findListing = await Listing.findById(id).populate({path : "reviews",populate:{path:"author"}}).populate("owner");
    res.render("listings/show.ejs",{findListing});
}
module.exports.createListing = async(req,res)=>{
    let url = req.file.path;
    let {filename}=req.file;
    const newListing = new Listing(req.body);
    newListing.owner = req.user._id;
    newListing.image = {url,filename}
    const response = await fetch(
      `https://api.maptiler.com/geocoding/${encodeURIComponent(req.body.location)}.json?key=zgvwmj5vTPudggwSmWOV`
    );
    const data = await response.json();
    console.log("Full data:", data.features[0].geometry); 
    newListing.geometry = data.features[0].geometry ;
    console.log(newListing)
    await newListing.save(); 
    req.flash("success", "New Listing added");
    res.redirect("/listings");
}
module.exports.edit = async(req,res)=>{
    let {id} = req.params;
    const editListing = await Listing.findById(id);
    res.render("listings/edit.ejs",{editListing});
}
module.exports.updateListing = async(req,res)=>{
    let {id} = req.params;
    let updatedListing = await Listing.findByIdAndUpdate(id,req.body,{runValidators:true,new:true});
    if(req.file){
        let url = req.file.path;
        let {filename}=req.file;
        updatedListing.image = {url,filename};
        await updatedListing.save();
    }
    req.flash("success","Listing Updated Successfully!")
    res.redirect(`/listings/${id}`);
}
module.exports.destroyListing = async(req,res)=>{
    let {id} = req.params;
    const delList = await Listing.findById(id);
    for(let revId of delList.reviews){
        await Review.findByIdAndDelete(revId);
    }
    await Listing.findByIdAndDelete(id);
    res.redirect("/listings");
}