const User = require("../models/user");

module.exports.signupPage = async(req,res)=>{
    res.render("users/signup.ejs");
}
module.exports.signup = async(req,res)=>{
    let {password,username,email,age,name} = req.body.user;
    const newUser = new User({username,email,age,name});
    const regUser = await User.register(newUser,password);
    req.login(regUser,(err)=>{
        if(err) return next(err);
        res.redirect("/listings");
    })
}
module.exports.loginPage = async(req,res)=>{
    res.render("users/login")
}
module.exports.login = async (req, res) => {
    req.flash("success", "Logged in Successfully ! ");
    res.redirect(res.locals.redirectURL || '/listings');
  } 