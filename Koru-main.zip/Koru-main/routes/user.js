const express = require("express");
const router = express.Router({ mergeParams: true });
const wrapAsync = require("../utils/wrapAsync");
const passport = require("passport");
const { saveRedirectPath, isLoggedIn ,validateUser } = require("../utils/middleware");
const userController = require("../controllers/user");

router
  .route("/signup")
  .get(wrapAsync(userController.signupPage))
  .post(validateUser, wrapAsync(userController.signup));
router
  .route("/login")
  .get(wrapAsync(userController.loginPage))
  .post(
    saveRedirectPath,
    passport.authenticate("local", {
      failureRedirect: "/users/login",
      failureFlash: true,
    }),
    wrapAsync(userController.login)
  );
router.get("/logout", isLoggedIn, (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    res.redirect("/listings");
  });
});
module.exports = router;