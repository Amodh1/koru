const express = require("express");
const router = express.Router({ mergeParams: true });
const wrapAsync = require("../utils/wrapAsync");
const { isLoggedIn, validateReview,isAuthor } = require("../utils/middleware");
const reviewController = require("../controllers/review");
router
  .route("/")
  .get(wrapAsync(reviewController.show))
  .post(isLoggedIn,validateReview, wrapAsync(reviewController.createReview));
router.delete(
  "/:reviewId",
  isLoggedIn,
  isAuthor,
  wrapAsync(reviewController.destroyReview)
);
module.exports = router;
