const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const listingSchema = new Schema({
    title: {
        type: String, 
        required: true
    },
    image: {
        url: {
            type:String,
            required:true
        },
        filename : {
            type : String,
            required:true
        }
    },
    location: {
        type: String, 
        required: true
    },
    price: {
        type: Number, 
        required: true
    },
    description: {
        type: String, 
        required: true
    },
    country: {
        type: String, 
        required: true
    },
    reviews: [{
        type: Schema.Types.ObjectId,
        ref: "Review"
    }],
    owner : {
        type: Schema.Types.ObjectId,
        ref: "User"
    },
    geometry:{
        type:{
            type:String ,
            enum: ["Point"],
            required: true
        },
        coordinates:{
            type:[Number],
            require:true
        }
    }
}) 

const Listing = mongoose.model("Listing", listingSchema);
module.exports = Listing; 