const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const passportLocalMongoose=require("passport-local-mongoose");

const userSchema = new Schema({
    email:{
        type : String ,
        required : true
    },
    name:{
        type : String,
        required : true
    },
    age:{
        type: Number,
        required : true
    }
})

userSchema.plugin(passportLocalMongoose);

const User = mongoose.model("User",userSchema);
module.exports =User;