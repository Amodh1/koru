const mongoose = require("mongoose");
const Listing = require("../models/listing");
const sdata = require("./data");
main()
  .then((res) => console.log("Connected to DB"))
  .catch((err) => console.log(err));

async function main() {
  await mongoose.connect("mongodb://127.0.0.1:27017/Koru");
}
const initDB = async () => {
  await Listing.deleteMany({});
  sdata.data = sdata.data.map((obj)=>{
    obj.owner = "68de75e2392c0f068a37d66e";
    return obj;
  })
  Listing.insertMany(sdata.data)
    .then((res) => {
      console.log("Inserted Successfully");
    })
    .catch((err) => {
      console.log(err);
    });
  console.log("Data was initialized");
};
initDB();
