if(process.env.NODE_ENV != 'production'){
  require("dotenv").config();
}
const express = require("express");
const app = express();
const port = process.env.PORT || 3000;
const path = require("path");
const mongoose = require("mongoose");
const methodOverride = require("method-override");
const ejsMate = require("ejs-mate");
const session = require("express-session");
const MongoStore = require('connect-mongo');
const flash = require("connect-flash")
const passport=require("passport");
const localStrategy = require("passport-local");
const listingRoutes = require("./routes/listings");
const reviewRoutes = require("./routes/review");
const userRoutes = require("./routes/user");
const User = require("./models/user");

const dbURL = process.env.ATLASDB_URL ;
const store = MongoStore.create({
   mongoUrl: dbURL,
   crypto:{
    secret:process.env.SECRET
   },
   touchAfter: 24*3600
  });
  store.on("error" , ()=>{
    console.log("Error in Mongo store !")
  })
const sessionOptions = {
  store,
  secret: process.env.SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: {
    expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    maxAge: 7 * 24 * 60 * 60 * 1000,
    httpOnly:true
  },
};
app.use(methodOverride("_method"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));
app.engine("ejs", ejsMate);

app.use(session(sessionOptions));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

passport.use(new localStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

main()
  .then((res) => console.log("Connected to DB"))
  .catch((err) => console.log(err));

async function main() {
  await mongoose.connect(dbURL);
}
app.get("/", (req, res) => {
  res.redirect("/listings");
});
//Middleware for flash messages
app.use((req,res,next)=>{
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  res.locals.user = req.user;
  next();
})
app.use("/listings", listingRoutes);
app.use("/listings/:id/review", reviewRoutes);
app.use("/users", userRoutes);
//Error Handling Middleware
app.use((err, req, res, next) => {
  const { statusCode = 500, message = "Something went wrong" } = err;
  res.status(statusCode).render("layouts/error.ejs", { message, statusCode });
});
app.listen(port, () => {
  console.log("Listening !");
});
